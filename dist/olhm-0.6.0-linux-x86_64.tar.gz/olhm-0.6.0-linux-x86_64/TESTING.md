# OLHM 0.6.0 — проверка в Linux VM

Этот пакет содержит консольную сборку для 64-битного Linux на архитектуре
`x86_64`. Бинарник статически связан с musl и не требует установки Rust, Nix или
динамических библиотек. Один и тот же файл предназначен для Debian/Ubuntu,
Fedora, openSUSE, Arch Linux, Alpine Linux и других актуальных дистрибутивов.

Графический интерфейс в переносимый пакет не включён: GUI использует системные
X11/Wayland и графические библиотеки, версии которых различаются между
дистрибутивами. Команда `gui` в этой сборке сообщит, что feature `gui` отключён.

## Проверка архива

Из каталога, где находятся архив и `SHA256SUMS`:

```sh
sha256sum -c SHA256SUMS --ignore-missing
tar -xzf olhm-0.6.0-linux-x86_64.tar.gz
cd olhm-0.6.0-linux-x86_64
./bin/olhm help
```

Запускайте OLHM от обычного пользователя. Для базовой проверки root не нужен.

## CPU

```sh
./bin/olhm info cpu
./bin/olhm snapshot cpu --interval 1
./bin/olhm monitor cpu --interval 1 --count 3
```

## RAM и swap

```sh
./bin/olhm info ram
./bin/olhm snapshot ram --interval 1
./bin/olhm monitor ram --interval 1 --count 3
```

## Накопители и файловые системы

```sh
./bin/olhm info storage
./bin/olhm snapshot storage --interval 1
./bin/olhm monitor storage --interval 1 --count 3
```

Базовые сведения берутся из `/proc` и `/sys`. Если в системе уже установлены
`lsblk` и `smartctl`, они необязательно дополняют разметку и SMART. Устанавливать
их только ради теста не требуется. SMART часто закрыт обычному пользователю —
в этом случае ожидается состояние «нет доступа», а не выдуманное «здоров».

В виртуальной машине температуры, энергопотребление, SMART и часть аппаратных
характеристик могут не передаваться гипервизором. Их отсутствие не является
ошибкой, если OLHM продолжает работать и показывает явный статус недоступности.

## Что сохранить для отчёта

```sh
uname -a > system.txt
cat /etc/os-release >> system.txt
./bin/olhm info cpu > cpu-info.txt
./bin/olhm snapshot cpu --interval 1 > cpu-snapshot.txt
./bin/olhm snapshot ram --interval 1 > ram-snapshot.txt
./bin/olhm snapshot storage --interval 1 > storage-snapshot.txt
```

Также полезно приложить вывод `lscpu`, `free -b`, `lsblk -b -O` и `df -B1`, если
эти команды уже доступны в гостевой системе. Не публикуйте серийные номера,
UUID и другие идентификаторы, если отчёт будет общедоступным.

Проверка считается успешной, если команды завершаются без падения, реальные нули
не смешиваются с недоступными данными, а объёмы и состав устройств соответствуют
системным инструментам с учётом различий методик и округления.
